<?php

##### funciones para la compra de bonos
function insertTransaction($db,$empresa){
    $table = '';
    switch ($empresa) {
        case 'Tigo':
            $table = 'transacciones_boton_tigo';
            break;
        case 'Personal':
            $table = 'transacciones_boton_personal';
            break;
    }

    $sql = " INSERT INTO ".DB_MBO.".".$table." (
                                                evento_boton
                                            )
                                            VALUES
                                            (
                                                1
                                            );";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $id_cab = $db->lastInsertId();
    return $id_cab;           
}
        
function insertPayment($db, $data,$prefijo="" ){
    $ref_trans = $data['ref_trans'];
    $id_cliente = $data['id_cliente'];
    $tel_trans = $data['tel_trans'];
    $monto_trans = $data['monto_trans'];
    $id_juego = $data['id_juego'];
    $empresa_trans = $data['empresa_trans'];
    $id_venta_bono = $data['id_venta_bono'];
    $fecha_ini_trans =$data['fecha_ini_trans'];
    $tipo_trans = $data['tipo_trans'];
    $estado_trans = $data['estado_trans'];
    $id_creador = $data['id_creador'];
    $fecha_creador = $data['fecha_creador'];
    $nombremodi_trans = $data['nombremodi_trans'];
    $fechamodi_trans = $data['fechamodi_trans'];

    $sucursal = $data['sucursal'];

    if( $data['empresa_trans'] == "tigo" ){
        $porcentaje = 0.03;
        $comision = (float)  $monto_trans * $porcentaje;
        $total = $monto_trans - $comision;
    }elseif( $data['empresa_trans'] == "personal" ){
        $porcentaje = 0.02;
        $comision = (float)  $monto_trans * $porcentaje;
        $total = $monto_trans - $comision;
    }elseif( $data['empresa_trans'] == "paypal" ){
        $porcentaje = 0.057;
        $comision = (float)  $monto_trans * $porcentaje;
        $total = $monto_trans - $comision;
    }
    
    $sql = " INSERT INTO ".DB_MBO.".".$prefijo."transacciones_bonos (
                                                ref_trans,
                                                id_cliente,
                                                tel_trans,
                                                monto_trans,
                                                comision_trans,
                                                id_juego,
                                                empresa_trans,
                                                fecha_ini_trans,
                                                tipo_trans,
                                                estado_trans,
                                                id_venta_bono,
                                                id_creador,
                                                fecha_creador,
                                                nombremodi_trans,
                                                fechamodi_trans,
                                                sucursal
                                            )
                                            VALUES
                                                (
                                                '$ref_trans',
                                                '$id_cliente',
                                                '$tel_trans',
                                                '$monto_trans',
                                                '$comision',
                                                '$id_juego',
                                                '$empresa_trans',
                                                '$fecha_ini_trans',
                                                '$tipo_trans',
                                                '$estado_trans',
                                                '$id_venta_bono',
                                                '$id_creador',
                                                '$fecha_creador',
                                                '$nombremodi_trans',
                                                '$fechamodi_trans',
                                                '$sucursal'
                                            );";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $id_cab = $db->lastInsertId();
    return $id_cab;                   
}

function transactionCompra($db,$idTrans,$empresa,$monto,$sucursal,$idCliente,$idCreador,$nombreCreador,$idJuego, $prefijo="",$sufijo=""){
    
    if($empresa == "tigo"){
        $compra = "Tigo Money";
        $cuenta = CONF_COMODIN['BONO_CAJA_BOTON_TIGO'];
        $porComision = CONF_COMODIN['POR_COMISION_BOTON_TIGO'] / 100;
        $cuentaEgreso = CONF_COMODIN['BONO_COMISION_BOTON_TIGO'];
    }elseif($empresa == "personal"){
        $compra = "Billetera Personal";
        $cuenta =  CONF_COMODIN['BONO_CAJA_BOTON_PERSONAL'];
        $porComision = CONF_COMODIN['POR_COMISION_BOTON_PERSONAL'] / 100;
        $cuentaEgreso = CONF_COMODIN['BONO_COMISION_BOTON_PERSONAL'];
    }elseif($empresa == "paypal"){
        $compra = "Billetera Paypal";
        $cuenta =  CONF_COMODIN['BONO_CAJA_BOTON_PAYPAL_USD'];
        $porComision = CONF_COMODIN['POR_COMISION_BOTON_PAYPAL_USD'] / 100;
        $cuentaEgreso = CONF_COMODIN['BONO_COMISION_BOTON_PAYPAL_USD'];
    }

    $fechaActual = date('Y-m-d H:i:s');
    $contable = new ContableV2();

    $montoComision = $monto * $porComision;
    $montoCaja = $monto - $montoComision;
    $montoVenta = $monto;

    //Asiento en el libro diario---------------------------------------------------------------------------------
    $descripcion = "Compra de bono por $compra";
    $debe = $monto;
    $haber = $monto;
    $idLibroDiario = $contable->asientoContable($db,$fechaActual, $descripcion, $debe, $haber, $idCreador, $nombreCreador, $sucursal ,$prefijo );

    //-----------------------------------------------------------------------------------------------------------

    //Asiento detalle libro de cuenta de caja -------------------------------------------------------------------
    $cuentaCaja = $cuenta; 
    $signo = "+";
    $debe = $montoCaja;
    $haber = 0;
    // throw new Exception ( "$db,$idLibroDiario, $cuentaCaja, $debe, $haber, $signo, $idCreador, $nombreCreador, $sucursal, $prefijo" );

    $contable->asientoDetalleLibro($db,$idLibroDiario, $cuentaCaja, $debe, $haber, $signo, $idCreador, $nombreCreador, $sucursal, $prefijo );

    //-----------------------------------------------------------------------------------------------------------

    //Asiento detalle libro de la billetera general--------------------------------------------------------------
    $cuentaVenta =  CONF_COMODIN['CUENTA_VENTA_BONOS']; 
    $signo = "+";
    $debe = 0;
    $haber = $montoVenta;
    $contable->asientoDetalleLibro($db,$idLibroDiario, $cuentaVenta, $debe, $haber, $signo, $idCreador, $nombreCreador, $sucursal, $prefijo );
    //-----------------------------------------------------------------------------------------------------------

    //Asiento detalle libro de la billetera general--------------------------------------------------------------
    $signo = "+";
    $debe = $montoComision;
    $haber = 0;
    $contable->asientoDetalleLibro($db,$idLibroDiario, $cuentaEgreso, $debe, $haber, $signo, $idCreador, $nombreCreador, $sucursal, $prefijo );

    //-----------------------------------------------------------------------------------------------------------

    //Asiento detalle libro cliente
    $haber = $monto;
    $debe = 0;
    $saldoCliente = $contable->saldoCliente($db, $idCliente, $prefijo );
    $contable->asientoDetalleLibroCliente($db, $idLibroDiario, $idCliente, $debe, $haber, $signo, $descripcion, $idCreador, $nombreCreador, $fechaActual,$idJuego,$sucursal,$saldoCliente,4,$prefijo);


    $actualizarCuenta = " UPDATE ".DB_CON.".".$prefijo."cuentas SET  total_cuenta = total_cuenta + $montoCaja  WHERE id_cuenta = '$cuentaCaja' ";
    $db->query($actualizarCuenta);
    
    $actualizarCuenta = " UPDATE ".DB_CON.".".$prefijo."cuentas SET  total_cuenta = total_cuenta + $montoVenta  WHERE id_cuenta = '$cuentaVenta' ";
    $db->query($actualizarCuenta);
    
    $actualizarCuenta = " UPDATE ".DB_CON.".".$prefijo."cuentas SET  total_cuenta = total_cuenta + $montoComision  WHERE id_cuenta = '$cuentaEgreso' ";
    $db->query($actualizarCuenta);
    
    $sql = " UPDATE ".DB_MBO.".".$prefijo."transacciones_bonos SET id_libro='$idLibroDiario' WHERE id_trans = '$idTrans' ";
    $db->query($sql);


}

function addBonosCompra($db,$idCliente,$monto,$juego,$idTrans,$sucursal,$id_venta_bono,$prefijo){
    $fecha = date('Y-m-d H:i:s');
    $totalBonos = $monto;
    $array = [];

    $sql = " SELECT * FROM ".DB_MBO.".juegos WHERE id_juego = '$juego'";
    $stmt = $db->query($sql);
    $r = $stmt->fetch(PDO::FETCH_OBJ);
    $valor_credito = $r->valor_credito;

    $array['idTrans'] = $idTrans;
    $array['sucursal'] = $sucursal;
    $array['nombreModiDetLibro'] = "Web Form";
    $array['duracion'] = 360;
    $array['idJuego'] = $juego;
    $array['idCreador'] = 0;
    $array['idCliente'] = $idCliente;
    $array['idTipo'] = 0;
    $array['idAsig'] = $id_venta_bono;
    $credito = ( $totalBonos /  $valor_credito  );
    $array['credito'] = $credito;
    $array['origen'] = '4';
    insertDbBonosCompra($db,$array,$prefijo);

    $sql = "
        SELECT 
            * 
        FROM ".DB_MBO.".venta_bonos a 
            join ".DB_BONO.".tipos t on t.id_tipo=a.id_bono
            join ".DB_MBO.".juegos j on j.id_juego=a.id_juego
        WHERE  
            a.estado_venta_bono = 0
            AND a.inicio_venta_bono <= '$fecha'
            AND a.fin_venta_bono >= '$fecha'
            AND a.id_venta_bono = '$id_venta_bono'
    ";

    $stmt = $db->query($sql);
    $query = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if ($query) {
        $credito = 0;
        foreach ($query as $key => $row) {
            if ( $row['id_juego'] == $juego ){
                $limitInferior = (float) $row['limite_inferior_tipo'];
                $limitSuperior = (float) $row['limite_superior_tipo'];
                $valor = (float) $row['valor_tipo'];
                $valor_juego = (float) $row['valor_credito'];
                $duracion = $row['duracion'];
                $idTipo = $row['id_tipo'];
                $idAsig = $row['id_venta_bono'];

                $array = [];
                if($row['tipo_valor_tipo'] == 1){
                    if( $limitInferior <= $monto && $limitSuperior >= $monto  ){
                        $subTotal = ( ( $valor/100) * $monto );
                        $credito = round( $subTotal / $valor_juego );
                    }elseif( $limitInferior == 0 && $limitSuperior == 0 ){
                        $subTotal = ( ( $valor/100) * $monto );
                        $credito = round( $subTotal / $valor_juego );
                    }

                    $array['idCliente'] = $idCliente;
                    $array['idTipo'] = $idTipo;
                    $array['idTrans'] = $idTrans;
                    $array['duracion'] = $duracion;
                    $array['idJuego'] = $juego;
                    $array['idCreador'] = 0;
                    $array['nombreModiDetLibro'] = "Web Form";
                    $array['sucursal'] = $sucursal;
                    $array['credito'] = $credito;
                    $array['idAsig'] = $idAsig;
                    $array['origen'] = '1';
                    
                    insertDbBonosCompra($db,$array,$prefijo);

                }else{

                    if( $limitInferior <= $monto && $limitSuperior >= $monto  ){
                        $subTotal = $valor;
                        $credito = round( $subTotal);
                    }elseif( $limitInferior == 0 && $limitSuperior == 0 ){
                        $subTotal = $valor;
                        $credito = round( $subTotal);
                    }

                    $array['idCliente'] = $idCliente;
                    $array['idTipo'] = $idTipo;
                    $array['idTrans'] = $idTrans;
                    $array['duracion'] = $duracion;
                    $array['idJuego'] = $juego;
                    $array['idCreador'] = 0;
                    $array['nombreModiDetLibro'] = "Web Form";
                    $array['sucursal'] = $sucursal;
                    $array['credito'] = $credito;
                    $array['idAsig'] = $idAsig;
                    
                    insertDbBonosCompra($db,$array,$prefijo);

                }
            }
        }
    } 

}

function insertDbBonosCompra($db,$array,$prefijo=""){
    $idJuego = $array['idJuego'];
    $duracion = $array['duracion'];
    $idCreador = $array['idCreador'];
    $idCliente = $array['idCliente'];
    $idAsig = $array['idAsig'];
    $idTipo = $array['idTipo'];
    $credito = $array['credito'];
    $nombreModiDetLibro = $array['nombreModiDetLibro'];
    $idTrans= $array['idTrans'];
    $sucursal = $array['sucursal'];
    $origen = $array['origen'];
    
    $fechaActual = date('Y-m-d H:i:s');
    $vencimiento = strtotime ( "+".$duracion." days" , strtotime ( $fechaActual ) ) ;
    $vencimiento = date('Y-m-d H:i:s', $vencimiento);

    $sqlBono = "
        INSERT INTO ".DB_BONO.".cliente_bono
        (
            id_cliente,
            id_venta_bono,
            id_tipo,
            fecha_cliente_tipo,
            duracion,
            credito,
            origen_bono,
            id_juego,
            fecha_vencimiento,
            id_creador,
            nombremodi_cliente_bono,
            fechamodi_cliente_bono,
            sucursal
        )
        VALUES(
            $idCliente,
            $idAsig,
            $idTipo,
            '$fechaActual',
            $duracion,
            $credito,
            '$origen',
            $idJuego,
            '$vencimiento',
            $idCreador,
            '$nombreModiDetLibro',
            '$fechaActual',
            $sucursal
        )
    ";

    $stmt = $db->prepare($sqlBono);
    $stmt->execute();
    $idClienteBono = $db->lastInsertId();

    $sqlBono = "
        INSERT INTO ".DB_BONO.".".$prefijo."det_trans_bonos
        (
            id_trans,
            id_cliente_bono,
            id_cliente
        )
        VALUES(
            $idTrans,
            $idClienteBono,
            $idCliente
        )
    ";
    $db->query($sqlBono);    
}
