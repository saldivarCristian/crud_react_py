<?php
namespace Clases\Admin\Fanaticos;
use \PDO;
// print_r($settings);
class Votaciones {
    private $log;
    function __construct($log =null) 
    {
        $this->log = $log;
    }

    /**
     * Undocumented function
     *
     * @param [type] $db conexion de base de datos
     * @param array $verComlumnas si se quiere obtener una columna
     * @return void
     */
    public static function listar(pdo $db, $verComlumnas=[]): array
    {
        
        $columna = "*";
        if (count($verComlumnas)) {
            $columna = implode(",", $verComlumnas);
        }
        $sql = "SELECT $columna FROM ".DB_BASE.".fanatico_votaciones";
        $stmt = $db->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_OBJ);
        return $data;
    }

    /**
     * Undocumented function
     *
     * @param [type] $db conexion de base de datos
     * @param [type] $id_votacion filtar votaciones por id_votacion
     * @return void
     */
    public static function getDataByNombre($db, $id)
    {
        $sqlCliente = "SELECT
                   *
                FROM ".DB_BASE.".fanatico_votaciones WHERE id_votacion = '$id'";
        $stmt = $db->query($sqlCliente);
        $data = $stmt->fetch(PDO::FETCH_OBJ);
        return $data;
    }

    /**
     * Undocumented function
     *
     * @param [type] $db conexion de base de datos
     * @param [type] $nombre_club filtar votaciones por nombre_club
     * @return void
     */
    public static function getDataByCuil($db, $nombre_club)
    {
        $sql = "SELECT
                   *
                FROM ".DB_BASE.".fanatico_votaciones WHERE id_votacion = '$nombre_club'";
        $stmt = $db->query($sql);
        $data = $stmt->fetch(PDO::FETCH_OBJ);
        return $data;
    }

    public function insertar($db,$obj = [])
    {
        if(!count($obj)){
            return 0;
        }
        $columnaAInsertar = "";
        $variableAInsertar = "";
        $bandera = 0;
        foreach ($obj as $key => $value) {
            if($bandera == 0){
                $bandera++;
                $columnaAInsertar .= $key;
                $variableAInsertar .= ":".$key;
            }else{
                $columnaAInsertar .= ",".$key;
                $variableAInsertar .= ",:".$key;  
            }
        }
        
        $sql = "
            INSERT INTO ".DB_BASE.".fanatico_votaciones (
                $columnaAInsertar
            )
            VALUES (
                $variableAInsertar   
            )
        ";
        $stmt = $db->prepare($sql);

        foreach ($obj as $key => $value) {
            $stmt->bindValue(':'.$key, $value);
        }
        try {
            $stmt->execute();
            $id = $db->lastInsertId();
            return $id;
            //code...
        } catch (\Throwable $th) {
            if ($this->log) {
                ob_start();
                $stmt->debugDumpParams();
                $r = ob_get_contents();
                $this->log->error( $r );
                ob_end_clean();
            }
            throw $th;
        }
    }

    public function actualizar($db,$obj = [],$id_update)
    {
        if(!count($obj)){
            return 0;
        }
        $columnaActualizar = "";
        $bandera = 0;
        $update = "";
        foreach ($obj as $key => $value) {
            if($bandera == 0){
                $bandera++;
                $columnaActualizar .= $key." = :".$key;
                $update .= "$key='$value'";
            }else{
                $columnaActualizar .= ",".$key." = :".$key;
                $update .= ",$key='$value'";
            }
        }
        
        $sql = "
            update ".DB_BASE.".fanatico_votaciones set
                $columnaActualizar
           where id_votacion = $id_update
        ";
   
        $stmt = $db->prepare($sql);
        foreach ($obj as $k => $v) {
            $stmt->bindValue(':'.$k, $v );
        }

        try {
            $stmt->execute();
            $id = $stmt->rowCount();
            return  1;
        } catch (\PDOException $th) {
            if ($this->log) {
                ob_start();
                $stmt->debugDumpParams();
                $r = ob_get_contents();
                $this->log->error( $r );
                ob_end_clean();
            }
            throw $th;
        }
       
    }

    public function eliminar($db,$id_update)
    {        
        $sql = "
            DELETE FROM ".DB_BASE.".fanatico_votaciones where id_votacion = $id_update
        ";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $id = $db->lastInsertId();
        return $id;
    }

    /**
     * Undocumented function
     *
     * @param pdo $db
     * @param [type] $id_cliente
     * @param array $verComlumnas
     * @return array
     */
    public static function getDataById(pdo $db, $id_cliente, $verComlumnas=[]): object
    {
        $columna = "*";
        if (count($verComlumnas)) {
            $columna = implode(",", $verComlumnas);
        }
        $sql = "SELECT $columna FROM ".DB_BASE.".fanatico_votaciones WHERE id_cliente = $id_cliente";
        $stmt = $db->query($sql);
        $data = $stmt->fetch(PDO::FETCH_OBJ);
        return $data;
    }
   
        /**
     * Undocumented function
     *
     * @param pdo $db
     * @param [type] $id_cliente
     * @param array $verComlumnas
     * @return array
     */
    public static function getAllDataById(pdo $db, $id_cliente, $verComlumnas=[])
    {
        $columna = "*";
        if (count($verComlumnas)) {
            $columna = implode(",", $verComlumnas);
        }
        $sql = "
               SELECT $columna
                FROM ".DB_BASE.".fanatico_votaciones v
                JOIN ".DB_BASE.".fanatico_futbolistas f ON f.id_futbolista= v.id_futbolista 
                WHERE v.id_cliente = $id_cliente";
        $stmt = $db->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_OBJ);
        return $data;
    }

    public static function getListCalification(pdo $db, $idEncuentro="", $idCliente = "" )
    {
        $where = "";
        if ($idEncuentro !="" ) {
            $where .= " and v.id_encuentro = $idEncuentro ";
        }

        if ($idCliente !="" ) {
            $where .= " and id_cliente = $idCliente ";
        }

        $sql = "
            SELECT 
            f.id_futbolista,
            f.imagen_futbolista,
            f.nombre_futbolista,
            f.apellido_futbolista,
            COALESCE( SUM( v.calificacion_votacion ),0) votos ,
            COALESCE( COUNT( v.id_futbolista ),0 ) cantidad ,
            COALESCE( ( SUM(v.calificacion_votacion) /  COUNT(v.id_futbolista)),0 )  promedio,
            COALESCE( ( 100 * ( SUM(v.calificacion_votacion)) / COUNT(v.id_futbolista) ) / 10 ,0 )  porcentaje
                FROM ".DB_BASE.".fanatico_votaciones v 
                right JOIN ".DB_BASE.".fanatico_futbolistas f ON f.id_futbolista= v.id_futbolista  $where
            WHERE f.estado_futbolista = 0 
            GROUP BY f.id_futbolista 
            ORDER BY promedio DESC
           
        ";
        $stmt = $db->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_OBJ);
        return $data;
    }

    public static function getListCalificationEncuetro(pdo $db, $idEncuentro="", $idCliente = "" )
    {
        $fecha = date('Y-m-d');

        $sql = "
            SELECT e.id_encuentro,e.fecha_encuentro,t.nombre_torneo ,e.dia_encuentro,e.hora_encuentro
            FROM ".DB_BASE.".fanatico_encuentros e 
                join fanatico_torneos t on t.id_torneo = e.id_torneo  
            
            order by e.dia_encuentro desc limit 6
        ";

        // where e.dia_encuentro < '$fecha'
        $stmt = $db->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_OBJ);
        $arrayEncuentros = [];
        foreach ($data as $key => $value) {
            $id = $value->id_encuentro;
            $sql = "
                SELECT 
                f.id_futbolista,
                f.imagen_futbolista,
                f.nombre_futbolista,
                f.apellido_futbolista,
                COALESCE( SUM( v.calificacion_votacion ),0) votos ,
                COALESCE( SUM( v.id_futbolista ),0 ) cantidad ,
                COALESCE( ( SUM(v.calificacion_votacion) /  COUNT(v.id_futbolista)),0 )  promedio,
                COALESCE( ( 100 * ( SUM(v.calificacion_votacion)) / COUNT(v.id_futbolista) ) / 10 ,0 )  porcentaje
                    FROM ".DB_BASE.".fanatico_votaciones v 
                    right JOIN ".DB_BASE.".fanatico_futbolistas f ON f.id_futbolista= v.id_futbolista
                WHERE f.estado_futbolista = 0 and v.id_encuentro = $id
                GROUP BY f.id_futbolista
                ORDER BY promedio DESC
            
            ";
            $stmt2 = $db->query($sql);
            $arrayCalificacion = $stmt2->fetchAll(PDO::FETCH_OBJ);
            $arrayEncuentros[] = [
                'id_encuentro' => $value->id_encuentro,
                'dia_encuentro' => date("d/m/Y",strtotime($value->dia_encuentro)),
                'hora_encuentro' => $value->hora_encuentro,
                'fecha_encuentro' => $value->fecha_encuentro,
                'nombre_torneo' => $value->nombre_torneo,
                'calificacion' => $arrayCalificacion,
            ];
        }
        return $arrayEncuentros;
    }
    
}
